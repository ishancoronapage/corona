import warnings
import sqlite3
import json
import pandas as pd
import requests
import matplotlib.pyplot as plt
from django.shortcuts import render
from fbprophet import Prophet
from datetime import date, timedelta


# warnings.filterwarnings('ignore')
# india_data = requests.get('https://pomber.github.io/covid19/timeseries.json')
# json_file = india_data.json()
# india = pd.read_json(json.dumps(json_file['India']))
# # Put India Data in DB
# # print(india)

connect = sqlite3.connect('C:\Python\PycharmProjects\Corono\db.sqlite3')
cursor = connect.cursor()
# split_date = '2020-04-06'
predicition = pd.read_sql_query("select * from cases_india", connect)
# c3.execute(sql3)
# data3 = c3.fetchall()
# # print(data)
# c3.execute(sql3)

con = predicition[['date', 'confirmed']]
rec = predicition[['date', 'recovered']]
det = predicition[['date', 'deaths']]

con.columns = ['ds', 'y']
rec.columns = ['ds', 'y']
det.columns = ['ds', 'y']

con['ds'] = pd.to_datetime(con['ds'])
rec['ds'] = pd.to_datetime(rec['ds'])
det['ds'] = pd.to_datetime(det['ds'])
# con.tail(10)
# print(con.tail(10))

con = con.set_index(con['ds'])
rec = rec.set_index(rec['ds'])
det = det.set_index(det['ds'])
del con['ds']
del rec['ds']
del det['ds']
# con.tail(5)
# print(con.tail(5))

con_diff = con.diff(periods=1)
rec_diff = rec.diff(periods=1)
det_diff = det.diff(periods=1)
con_diff['ds'] = con_diff.index
rec_diff['ds'] = rec_diff.index
det_diff['ds'] = det_diff.index

con_train_last = con.loc['2020-04-06'].copy()
rec_train_last = rec.loc['2020-04-06'].copy()
det_train_last = det.loc['2020-04-06'].copy()


split_date = str(date.today() - timedelta(5))
train_first = '2020-04-01'
train_con = con_diff.loc[(con_diff['ds'] > train_first) & (con_diff['ds'] <= split_date)].copy()
test_con = con_diff.loc[con_diff.index > split_date].copy()
train_rec = rec_diff.loc[(rec_diff['ds'] > train_first) & (rec_diff['ds'] <= split_date)].copy()
test_rec = rec_diff.loc[rec_diff.index > split_date].copy()
train_det = det_diff.loc[(det_diff['ds'] > train_first) & (det_diff['ds'] <= split_date)].copy()
test_det = det_diff.loc[det_diff.index > split_date].copy()

modelc = Prophet(interval_width=0.95)
modelc.fit(train_con)
modelr = Prophet(interval_width=0.95)
modelr.fit(train_rec)
modeld = Prophet(interval_width=0.95)
modeld.fit(train_det)

con_diff_prediction = modelc.predict(test_con)
con_diff_prediction[['yhat', 'ds']].round()
# print(con_train_last)
rec_diff_prediction = modelr.predict(test_rec)
rec_diff_prediction[['yhat', 'ds']].round()
# print(con_train_last)
det_diff_prediction = modeld.predict(test_det)
det_diff_prediction[['yhat', 'ds']].round()
# print(con_train_last)

con_cum_prediction = con_diff_prediction
# print(cum_prediction['yhat'][0])
con_cum_prediction['yhat'][0] = con_cum_prediction['yhat'][0] + con_train_last
# print(cum_prediction['yhat'][0].round())
con_cum_prediction['yhat'] = con_cum_prediction['yhat'].cumsum()
# print(cum_prediction['yhat'].round())
con_cum_prediction['yhat'] = con_cum_prediction['yhat'].round()
# print(con['y'].tail(8))
con_cum_prediction = con_cum_prediction.set_index(con_cum_prediction['ds'])

rec_cum_prediction = rec_diff_prediction
# print(cum_prediction['yhat'][0])
rec_cum_prediction['yhat'][0] = rec_cum_prediction['yhat'][0] + rec_train_last
# print(cum_prediction['yhat'][0].round())
rec_cum_prediction['yhat'] = rec_cum_prediction['yhat'].cumsum()
# print(cum_prediction['yhat'].round())
rec_cum_prediction['yhat'] = rec_cum_prediction['yhat'].round()
# print(con['y'].tail(8))
rec_cum_prediction = rec_cum_prediction.set_index(rec_cum_prediction['ds'])

det_cum_prediction = det_diff_prediction
# print(cum_prediction['yhat'][0])
det_cum_prediction['yhat'][0] = det_cum_prediction['yhat'][0] + det_train_last
# print(cum_prediction['yhat'][0].round())
det_cum_prediction['yhat'] = det_cum_prediction['yhat'].cumsum()
# print(cum_prediction['yhat'].round())
det_cum_prediction['yhat'] = det_cum_prediction['yhat'].round()
# print(con['y'].tail(8))
det_cum_prediction = det_cum_prediction.set_index(det_cum_prediction['ds'])

c_compare = pd.concat([con, con_cum_prediction], axis=1, join='inner')
# print(compare[['y', 'yhat']])
r_compare = pd.concat([rec, rec_cum_prediction], axis=1, join='inner')
# print(compare[['y', 'yhat']])
d_compare = pd.concat([det, det_cum_prediction], axis=1, join='inner')
# print(compare[['y', 'yhat']])

for row in c_compare:
    c_compare['percentage'] = ((c_compare['y'] - c_compare['yhat']) / c_compare['y']) * 100
    c_compare['percentage'].append
# print(compare[['y', 'yhat', 'percentage']])
for row in r_compare:
    r_compare['percentage'] = ((r_compare['y'] - r_compare['yhat']) / r_compare['y']) * 100
    r_compare['percentage'].append
# print(compare[['y', 'yhat', 'percentage']])
for row in d_compare:
    d_compare['percentage'] = ((d_compare['y'] - d_compare['yhat']) / d_compare['y']) * 100
    d_compare['percentage'].append
# print(compare[['y', 'yhat', 'percentage']])

#  Future Prediction

first_train = '2020-03-24'
last_train = '2020-04-07'
c_train1 = con_diff.loc[(con_diff['ds'] > first_train) & (con_diff['ds'] <= last_train)].copy()
# test1 = con_diff.loc[con_diff.index > split_date].copy()
cmodel1 = Prophet(interval_width=0.95)
cmodel1.fit(c_train1)
r_train1 = rec_diff.loc[(rec_diff['ds'] > first_train) & (rec_diff['ds'] <= last_train)].copy()
# test1 = con_diff.loc[con_diff.index > split_date].copy()
rmodel1 = Prophet(interval_width=0.95)
rmodel1.fit(r_train1)
d_train1 = det_diff.loc[(det_diff['ds'] > first_train) & (det_diff['ds'] <= last_train)].copy()
# test1 = con_diff.loc[con_diff.index > split_date].copy()
dmodel1 = Prophet(interval_width=0.95)
dmodel1.fit(d_train1)

days = 24
c_future = cmodel1.make_future_dataframe(periods=days)
con_future = cmodel1.predict(c_future)
con_future_ds = con_future[['ds', 'yhat']]
# print(con_future_ds.round())
con_cum_predict2 = con_future
# print(cum_predict2['yhat'][0])
r_future = rmodel1.make_future_dataframe(periods=days)
rec_future = rmodel1.predict(r_future)
rec_future_ds = rec_future[['ds', 'yhat']]
# print(con_future_ds.round())
rec_cum_predict2 = rec_future
# print(cum_predict2['yhat'][0])future = model1.make_future_dataframe(periods=24)
d_future = dmodel1.make_future_dataframe(periods=days)
det_future = dmodel1.predict(d_future)
det_future_ds = det_future[['ds', 'yhat']]
# print(con_future_ds.round())
det_cum_predict2 = det_future
# print(cum_predict2['yhat'][0])


con_train_last = con.loc['2020-04-01'].copy()
con_cum_predict2['yhat'][0] = con_cum_predict2['yhat'][0] + con_train_last
# print(cum_predict2['yhat'][0].round())
con_cum_predict2['yhat'] = con_cum_predict2['yhat'].cumsum()
con_cum_predict2['yhat'].round()
# print(cum_predict2[['ds', 'yhat']].round())
con_cum_predict2 = con_cum_predict2.set_index(con_cum_predict2['ds'])

rec_train_last = rec.loc['2020-04-01'].copy()
rec_cum_predict2['yhat'][0] = rec_cum_predict2['yhat'][0] + rec_train_last
# print(cum_predict2['yhat'][0].round())
rec_cum_predict2['yhat'] = rec_cum_predict2['yhat'].cumsum()
rec_cum_predict2['yhat'].round()
# print(cum_predict2[['ds', 'yhat']].round())
rec_cum_predict2 = rec_cum_predict2.set_index(rec_cum_predict2['ds'])

det_train_last = det.loc['2020-04-01'].copy()
det_cum_predict2['yhat'][0] = det_cum_predict2['yhat'][0] + det_train_last
# print(cum_predict2['yhat'][0].round())
det_cum_predict2['yhat'] = det_cum_predict2['yhat'].cumsum()
det_cum_predict2['yhat'].round()
# print(cum_predict2[['ds', 'yhat']].round())
det_cum_predict2 = det_cum_predict2.set_index(det_cum_predict2['ds'])

for row in con_cum_predict2[['yhat']]:
    con_cum_predict2[['confirmed']] = con_cum_predict2[['yhat']]
    con_cum_predict2[['confirmed']].append(con_cum_predict2[['yhat']])
# print(con_cum_predict2[['confirmed']])
for row in rec_cum_predict2[['yhat']]:
    rec_cum_predict2[['recovered']] = rec_cum_predict2[['yhat']]
    rec_cum_predict2[['recovered']].append(rec_cum_predict2[['yhat']])
# print(rec_cum_predict2[['recovered']])
for row in det_cum_predict2[['yhat']]:
    det_cum_predict2[['deaths']] = det_cum_predict2[['yhat']]
    det_cum_predict2[['deaths']].append(det_cum_predict2[['yhat']])
# print(det_cum_predict2[['deaths']])

final = pd.concat([con_cum_predict2[['confirmed']].round(), rec_cum_predict2[['recovered']].round(), det_cum_predict2[['deaths']].round()], axis=1, join='inner')
# print(final)

# for row in final:
#     final[['confirmed']] = final[['active']].round() + final[['recovered']].round() + final[['deaths']].round()
#     final[['confirmed']].append
# print(final[['confirmed']])

compare2 = pd.concat([con, con_cum_predict2], axis=1, join='inner')

for row in compare2:
    compare2['percentage'] = ((compare2['y'] - compare2['yhat']) / compare2['y']) * 100
    compare2['percentage'].append
# print(compare2[['y', 'yhat', 'percentage']].round(2))

x = con_cum_predict2['yhat']
y = con_cum_predict2['ds']
plt.plot(x, y)
# plt.show()

