import sqlite3
import pandas as pd
from datetime import date, timedelta


# cnx = sqlite3.connect('C:\Python\PycharmProjects\Corono\db.sqlite3')
#
# df = pd.read_sql_query("SELECT * FROM cases_predictions", cnx)

# print(df)

conn = sqlite3.connect('C:\Python\PycharmProjects\Corono\db.sqlite3')
c = conn.cursor()
sql = "select * from cases_statewise where state='Total'"
c.execute(sql)
data = c.fetchall()
print(data)

a = []
b = []
c = []

for row in data:
    a.append(row[8])
    b.append(row[0])
    c.append(row[2])

print(b)




